import os
import csv
import argparse
import importlib.metadata
import subprocess
from tqdm import tqdm
from .downloader import download_song
from .metadata_fetcher import get_clean_metadata
from .tagger import apply_metadata

# --- AUTOMATIC VERSIONING ---
def get_version():
    try:
        return importlib.metadata.version("mymusic-dl-Rajthespaceman")
    except importlib.metadata.PackageNotFoundError:
        return "1.4.6" 

__version__ = get_version()

def file_exists_fuzzy(query, search_dirs):
    """Checks for exact file or a file starting with the song name."""
    target = f"{query}.mp3"
    for d in search_dirs:
        if not os.path.exists(d): continue
        # Exact match
        if os.path.exists(os.path.join(d, target)): return True
        # Fuzzy/Prefix match
        try:
            track_name = query.split(" - ")[0] if " - " in query else query
            files = os.listdir(d)
            if any(f.lower().startswith(track_name.lower()) and f.endswith(".mp3") for f in files):
                return True
        except Exception: continue
    return False

def run_from_csv(csv_file):
    """Main execution logic for processing the CSV file."""
    os.system('cls' if os.name == 'nt' else 'clear')
    
    backup_dir = "backup"
    history_file = os.path.join(backup_dir, "downloaded_history.txt")
    failed_file = os.path.join(backup_dir, "failed_songs.txt") 
    
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    search_paths = [os.getcwd(), "downloads"]

    # --- 1. SMART SYNC: Check disk BEFORE trusting/wiping history ---
    downloaded_history = []
    if os.path.exists(history_file):
        with open(history_file, "r", encoding="utf-8") as h:
            stored_names = [line.strip() for line in h.readlines() if line.strip()]
        
        # Verify every name in the TXT actually exists in one of our folders
        valid_history = [name for name in stored_names if file_exists_fuzzy(name, search_paths)]
        
        if len(valid_history) != len(stored_names):
            diff = len(stored_names) - len(valid_history)
            # We only print this if the file is truly gone from both locations
            print(f"🧹 Syncing: Removed {diff} entries missing from disk (Checks current & downloads).")
            with open(history_file, "w", encoding="utf-8") as h:
                for name in valid_history: h.write(f"{name}\n")
            downloaded_history = valid_history
        else:
            downloaded_history = stored_names

    if not os.path.exists(csv_file):
        print(f"🎵 PRO MUSIC PIPELINE v{__version__}\n❌ Error: '{csv_file}' not found!")
        return

    # --- 2. Load Songs ---
    songs = []
    try:
        with open(csv_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                track = row.get('Track Name')
                artist = row.get('Artist Name(s)')
                if track and artist:
                    songs.append(f"{track} - {artist}")
    except Exception as e:
        print(f"❌ Failed to read CSV: {e}"); return

    # --- 3. Process ---
    failed_songs = []
    pbar = tqdm(songs, desc="📥 Progress", unit="song", dynamic_ncols=True)
    
    for query in pbar:
        # Check both the verified history list AND the disk again (just in case)
        if query in downloaded_history and file_exists_fuzzy(query, search_paths):
            continue

        success = False
        retries = 3 
        for attempt in range(retries):
            try:
                s_name, a_name = query.split(" - ", 1) if " - " in query else (query, "")
                data = get_clean_metadata(s_name, a_name)
                path = download_song(query)
                
                # FINAL VERIFICATION before logging success
                if path and os.path.exists(path):
                    if data: apply_metadata(path, data)
                    with open(history_file, "a", encoding="utf-8") as h:
                        h.write(f"{query}\n")
                    success = True
                    break 
            except Exception: continue 
        
        if not success:
            failed_songs.append(query)
            with open(failed_file, "a", encoding="utf-8") as f:
                f.write(f"{query}\n")

    print("\n✨ Process Complete!")
    if failed_songs:
        print(f"\n❌ {len(failed_songs)} failures. Check backup/failed_songs.txt")
    else:
        print("✅ All songs are synced and downloaded!")

def main():
    """Entry point for the CLI tool."""
    parser = argparse.ArgumentParser(prog="music")
    parser.add_argument("-i", "--input", help="CSV path", default="playlist.csv")
    parser.add_argument("-s", "--search", help="Single search", default=None)
    parser.add_argument("--open", help="Open music folder", action="store_true")
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")

    args = parser.parse_args()

    if args.open:
        path = os.path.abspath("downloads") if os.path.exists("downloads") else os.getcwd()
        os.startfile(path) if os.name == 'nt' else subprocess.run(['open', path])
        return

    if args.search:
        path = download_song(args.search)
        if path and os.path.exists(path):
            if " - " in args.search:
                s, a = args.search.split(" - ", 1)
                data = get_clean_metadata(s, a)
                if data: apply_metadata(path, data)
        return

    run_from_csv(args.input)

if __name__ == "__main__":
    main()