# 🎵 MyMusic Downloader (v1.3.1)

A high-performance, silent CLI tool designed to convert Spotify playlists into high-quality MP3s with 100% accurate metadata. This tool eliminates common glitches like wrong artist names or "remix" mismatches by using verified Exportify data and MusicBrainz matching.

## ✨ Features
* **Zero Spam UI**: A clean, single progress bar is the only thing that stays at the bottom of your terminal during the process.
* **Smart Resume**: Automatically detects a 'backup' folder and skips any songs you have already successfully downloaded.
* **Failure Tracking**: New in v1.1.0! Automatically logs failed downloads to 'backup/failed_songs.txt' for easy review.
* **Single Song Search**: Download a specific track instantly without needing a CSV file.
* **High-Quality Tags**: Stitches Title, Artist, Album, and Year directly into the MP3 metadata.
* **Global Access**: Once installed, run the 'music' command from any folder on your computer.

## 🚀 Installation
1. Ensure you have FFmpeg (https://ffmpeg.org/) installed and added to your system PATH.
2. Install the tool globally via PyPI:
   pip install mymusic-dl-Rajthespaceman
3. Or update your existing version:
   pip install --upgrade mymusic-dl-Rajthespaceman

## 📖 How to Use
This tool uses Exportify to bypass Spotify's web security and ensure 100% metadata accuracy.

### 1. Batch Download (Playlist Mode): 
* Go to Exportify (https://watsonbox.github.io/exportify/) and log in.
* Export your desired playlist as a CSV file.
* Run the command:
   music -i your_file.csv
   (Or just 'music' if your file is named playlist.csv)

### 2. Single Search Mode:
* If you just want one song, type:
   music -s "Artist Name - Song Title"

## 🛠️ CLI Commands & Arguments
* music: Runs the downloader using the default 'playlist.csv'.
* music -s "Search Query": Searches and downloads a single song.
* music -i <file.csv>: Specify a different CSV input file.
* music -h: Opens the help menu to see all available options.

## 📂 Backup & Safety
The tool automatically manages a '/backup' folder to save your progress.
* **Resume Capability**: If the process is interrupted, running 'music' again will resume exactly where you left off.
* **Skip Logic**: The tool reads 'downloaded_history.txt' to ensure you never waste data on the same song twice.
* **Error Logs**: Check 'failed_songs.txt' inside the backup folder to see which tracks need a manual retry.

## 📝 Troubleshooting
* **Pasting in Terminal**: If 'Ctrl+V' doesn't work in Windows CMD, Right-Click the terminal window to paste.
* **FFmpeg Error**: If the tool crashes during conversion, double-check that FFmpeg is installed and in your Environment Variables.